#define VERSION "3proxy-0.8.7"
#define BUILDDATE "160904162014"
